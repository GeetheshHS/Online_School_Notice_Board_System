Admin Login
email: admin@gmail.com
password: admin@123

User Login
email: kiran@gmail.com
password: 12345


In this Project
    Admin:  Dashboard,edit profile, create notice, view all notices.
     User:  Dashboard,edit profile, view all notices.

If you need documentation regarding this project please contact to my email.
-------------------nariklama2055@gmail.com----------------------------
